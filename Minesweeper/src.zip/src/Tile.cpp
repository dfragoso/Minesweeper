#include "pch.h"
#include "Tile.h"


Tile::Tile()
{

	isFlag = false;
	isMine = false;
	isClicked = false;
	visited = false;
	mineCount = 0;
}

